(function() {
  QUnit.config.noglobals = true;
}());
