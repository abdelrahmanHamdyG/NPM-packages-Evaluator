# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

## [4.0.0](https://github.com/lquixada/cross-fetch/compare/v4.0.0-alpha.13...v4.0.0) (2023-07-03)
