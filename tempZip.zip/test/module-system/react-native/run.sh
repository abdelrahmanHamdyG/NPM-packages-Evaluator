#!/bin/sh
npx mocha $(dirname "$0")/index.js
