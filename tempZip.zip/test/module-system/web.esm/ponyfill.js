import defaultExport, * as namedExports from '../../..'

window.defaultExport = defaultExport
window.namedExports = namedExports
