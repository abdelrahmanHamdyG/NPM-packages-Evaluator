package com.commcourier.exceptions;

import com.commcourier.restartifacts.ResponseCode;
import lombok.Getter;

@Getter
public class CommcourierException extends RuntimeException {

    private ResponseCode responseCode;

    public CommcourierException(ResponseCode responseCode) {
        this.responseCode = responseCode;

    }
}
